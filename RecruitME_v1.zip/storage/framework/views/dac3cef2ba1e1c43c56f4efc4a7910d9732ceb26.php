

<?php $__env->startSection('JobContent'); ?>

<?php if($dataJobPosts->count() > 0): ?>
<?php $__currentLoopData = $dataJobPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $djp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
	<?php $__env->startSection('__applyid__',$djp->id); ?>
	<?php $__env->startSection('__jobtitle__',$djp->title); ?>
	<div class="row">
		<div class="col-lg-12 mt-2">
			<?php if($errors->count() > 0): ?>
			<div class="alert alert-info">
				<p>Attention!</p>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($err); ?><br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endif; ?>

			<?php if(!empty(Session::get('success'))): ?>
			<div class="alert alert-info">
				<p>Thankyou!</p>
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>
			<div class="bg-custom p-2 text-light">
				<div class="d-flex w-100 justify-content-between">
			      	<h5 class="mb-1"><?php echo e($djp->title); ?></h5>
			      	<small>Created at <?php echo e($djp->created_at->diffForHumans()); ?></small>
			    </div>
			    <small>On <strong><?php echo e($djp->categories); ?></strong> Categories</small>			    
			</div>
			<div class="bg-light p-2 text-dark rounded-lg">
				<div>
			    	<?php echo $djp->posts; ?>

			    </div>
			</div>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="container">
	<div class="alert alert-info">
		<p>Ups!,</p>
		Sorry, This jobs has been deleted!
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.job-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AdmiN\Documents\LaravelProject\Recruitment\resources\views/layout/job.blade.php ENDPATH**/ ?>