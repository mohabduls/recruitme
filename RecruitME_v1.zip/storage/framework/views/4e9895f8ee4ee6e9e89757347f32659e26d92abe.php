

<?php $__env->startSection('LoginContent'); ?>

<div class="container mt-5">
	<div class="d-flex justify-content-center">
		<form class="form-custom p-4 bg-light shadow shadow-sm" method="POST" action="<?php echo e(url('auth')); ?>">
			<?php echo csrf_field(); ?>
			<div class="d-flex justify-content-center">
				<img src="<?php echo e(url('assets/img/recruitme.png')); ?>" alt="RecruitME Logo" class="img-logo">
			</div>
			<p class="lead text-center text-custom">RecruitME</p>
			<?php if($errors->count() > 0): ?>
			<div class="alert alert-danger">
				<p class="alert-header">Warning!</p>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($err); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<div class="form-group">
				<label class="form-label text-dark">Username</label>
				<input class="form-control input-custom" type="text" name="username" placeholder="Username">
				<small>Username *</small>
			</div>
			<div class="form-group">
				<label class="form-label text-dark">Password</label>
				<input class="form-control input-custom" type="password" name="password" placeholder="********">
				<small>Password *</small>
			</div>
			<button class="btn btn-sm btn-custom-login btn-block p-2">Login</button>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.login-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AdmiN\Documents\LaravelProject\Recruitment\resources\views/layout/login.blade.php ENDPATH**/ ?>