

<?php $__env->startSection('JobLists'); ?>


<div class="container">
	<?php $__env->startSection('__jobtitle__','Vacancy Available'); ?>
	<div class="row">
		<div class="col-lg-12">
			<div class="bg-light p-2 shadow shadow-sm text-custom rounded-lg">
				<div class="clearfix">
					<div class="float-left">
						<p class="display-6">Vacancy Available</p >
					</div>
					<div class="float-right">
						<form action="<?php echo e('vacancy'); ?>" method="GET">
							<div class="input-group input-group-sm mb-3">
								<div class="input-group-prepend">
									<div class="input-group-text">
										<span class="form-label">Find</span>
									</div>
								</div>
								<input class="form-control input-custom" type="text" name="find" placeholder="Find ?">
								<select class="form-control input-custom" name="cat">
									<option value="">Categories</option>
									<?php $__currentLoopData = $dataCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($dc->categories); ?>"><?php echo e($dc->categories); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<input class="btn btn-custom-rounded form-control" type="submit" value="Go">
							</div>
						</form>
					</div>
				</div>
				<?php if($dataJobPosts->count() > 0): ?>
				<div class="list-group">
					<?php $__currentLoopData = $dataJobPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $djp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="list-group-item list-group-item-action">
					    <div class="d-flex w-100 justify-content-between">
					      	<h5 class="mb-1"><?php echo e($djp->title); ?></h5>
					      	<small>Created at <?php echo e($djp->created_at->diffForHumans()); ?></small>
					    </div>
					    <small>On <strong><?php echo e($djp->categories); ?></strong> Categories</small>
					    <div class="clearfix">
					    	<div class="float-right">
					    		<object>
					    			<a href="<?php echo e(url('job/'.$djp->permalink)); ?>" class="btn btn-custom-rounded btn-sm" target="__blank">See</a>
					    		</object>
					    	</div>
					    </div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="clearfix mt-2">
					<div class="float-right">
						<?php echo e($dataJobPosts->links()); ?>

					</div>
				</div>
				<?php else: ?>
				<div class="container">
					<div class="alert alert-info">
						<p>Ups!,</p>
						Sorry, Currently we do not have any vacancy available!
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.joblists-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AdmiN\Documents\LaravelProject\Recruitment\resources\views/layout/joblists.blade.php ENDPATH**/ ?>