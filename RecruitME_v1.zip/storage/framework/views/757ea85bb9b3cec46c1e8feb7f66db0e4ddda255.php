<!DOCTYPE html>
<html>
	<head>
		<!--jobtitle-->
		<title><?php echo $__env->yieldContent('__jobtitle__'); ?></title>
		<meta charset="utf-8">
		<meta name="canonical" content="<?php echo e(url('/')); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">

		<!--assets-->
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/bootstrap.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/izimodal.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/recruitment.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/dashboard.css')); ?>">
		<script type="text/javascript" src="<?php echo e(url('assets/js/jquery-3.4.1.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(url('assets/js/bootstrap.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(url('assets/js/izimodal.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(url('assets/js/jobs.js')); ?>"></script>
	</head>
	<body>
		<header>
			<nav class="bg-light">
				<div class="container p-2">
					<div class="clearfix">
						<div class="float-left">
							<?php $__currentLoopData = $dataCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a class="navbar-brand text-custom" href="#"><?php echo e($dc->name); ?></a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="float-right">
							<button class="btn btn-custom-rounded" onclick="apply(this)" apply-id="<?php echo $__env->yieldContent('__applyid__'); ?>">Apply</button>
						</div>
					</div>
				</div>
			</nav>
		</header>
		<div class="wrapper">
			<?php echo $__env->yieldContent('JobContent'); ?>

			<!--include modals-->
			<?php echo $__env->make('modals.job', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<footer>
			<div class="container p-5 text-center">
				<strong><small class="text-custom">
					RecruitME v1.0<br>
					&copy; 2020 - <a class="text-custom text-decoration-none" href="https://www.linkedin.com/in/mohabduls" target="__blank">Mohamad Abdul Sobur</a></small></strong>
			</div>
		</footer>

		
	</body>
</html><?php /**PATH C:\Users\AdmiN\Documents\LaravelProject\Recruitment\resources\views/master/job-master.blade.php ENDPATH**/ ?>