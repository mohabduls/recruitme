

<?php $__env->startSection('HomeContent'); ?>
<div class="container">
	<div class="jumbotron bg-light">
		<div id="sliderTop" class="text-center">
			<div>
				<h1 class="display-5 text-custom">RecruitME</h1>
				<p class="lead text-custom">Recruit a candidate more easy with RecruitME!</p>
			</div>
			<div>
				<h1 class="display-5 text-custom">Download</h1>
				<p class="lead text-custom m-0">Download RecruitME Source Code.!</p>
				<small class="text-secondary">Build with Laravel 7+</small>
			</div>
		</div>
		<div class="p-5 text-center text-secondary">
			<p>Welcome to the official RecruitME website!</p>
			<p>RecruitME is a web-based application that functions to manage your site's recruitment!</p>
			<p>It's easy to redevelop because RecruitME was built with the Laravel 7+ framework.</p>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-sm-4">
			<p class="font-weight-bolder text-custom">RecruitME</p>
			<div class="bg-light">
				RecruitME is open-source Recruitment Platform apps who can handle your recruitment jobs!
			</div>
		</div>
		<div class="col-sm-4">
			<p class="font-weight-bolder text-custom">Feature</p>
			<div class="bg-light p-2">
				<ul>
					<li>Statistic.</li>
					<li>Filter by category.</li>
					<li>Download candidate as Zip format.</li>
				</ul>
			</div>
		</div>
		<div class="col-sm-4">
			<p class="font-weight-bolder text-custom">Download</p>
			<div class="bg-light">
				RecruitME is open-source Recruitment Apps,<br>
				You can download simply click button on the top!
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.index-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AdmiN\Documents\LaravelProject\s\Recruitment\resources\views/layout/index.blade.php ENDPATH**/ ?>